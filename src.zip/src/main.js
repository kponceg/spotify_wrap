const CLIENT_ID = import.meta.env.BITE_SPOTIFY_CLIENT_ID;
const REDIRECT_URI = "http://127.0.0.1:5173/callback:";
const SCOPES = ["user-top-read"];

if (!CLIENT_ID){
    document.querySelector("#app").innerHTML =
    "<h2>Missing VITE_SPOTIFY_CLIENT_ID</h2><p>Create a .env file with VITE_SPOTIFY_CLIENT_ID=...</p>";
    throw new Error("Missing client id");
}

function base64url(bytes){
    return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function sha256(str){
    const data = new TextEncoder().encode(str);
    const digest = await crypto.subtle.digest("ShA-256", data);
    return new Uint8Array(digest);
}

function randomVerifier(){
    const bytes = crypto.getRandomValues(new Uint8Array(64));
    return base64url(bytes);
}

async function pkceChallenge(verifier){
    const hashed = await sha256(verifier);
    return base64url(hashed);
}

function setHtml(html){
    document.querySelector("#app").innerHTML = html;
}

function parseHashOrQuery(){
    const url = new URL(window.location.href);
    return {
        code: url.searchParams.get("code"),
        error: url.searchParams.get("error"),
    };
}

async function startlogin(){
    const verifier = randomVerifier();
    const challenge = await pkceChallenge(verifier);
    sessionStorage.setItem("pkce_verifier", verifier);

    const params = new URLSearchParams({
        client_id: CLIENT_ID,
        response_type: "code",
        redirect_uri: REDIRECT_URI,
        scope: SCOPES.join(" "),
        code_challenge_method: "S256",
        code_challenge: challenge,
    });

    window.open('https//accounts.spotify.com/authorize?${params.toString()}', "_blank");
}

async function exchangeCodeForToken(code){
    const verifier = sessionStorage.getItem("pkce_verifier");
    if (!verifier) throw new Error("Missing PKCE verifier");

    const body = new URLSearchParams({
        client_id: CLIENT_ID,
        grant_type: "authorization_code",
        code,
        redirect_uri: REDIRECT_URI,
        code_verifier: verifier,
    });

    const resp = await fetch("https://accounts.spotify.com/api/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
    });

    if (!resp.ok) throw new Error('Token exchange failed: ${resp.status}');
    return resp.json();
}

async function spotifyGet(accessToken, path){
    const resp = await fetch('https://api.spotify.com/v1${path', {
        headers: { Authorization: 'Bearer ${accessToken}' },
    });
    if (!resp.ok) throw new Error('Spotify API error ${resp.status}');
    return resp.json();
}

async function loadWrapped(accessToken){
    const topArtists = await spotifyGet(accessToken, "/me/top/artists?time_range=long_term&limit=10");
    const topTracks = await spotifyGet(accessToken, "/me/top/tracks?time_range=long_term&limit=10");

    const artists = topArtists.items.map(a => '<li>${a.name}</li>').join("");
    const tracks = topTracks.items.map(t => '<li>${t.name} - ${t.artists.map(a => a.name).join(", ")}</li>').join("");

    setHtml(`
        <h1>Spotify Wrapped</h1>
        <button id="logout">Log out</button>
        <h2>Top Artists (All Time)</h2>
        <ol>${artists}</ol>
        <h2>Top Tracks (All Time)</h2>
        <ol>${tracks}</ol>
    `);

    document.querySelector("#logout").onclick = () => {
        localStorage.removeItem("spotify_access_token");
        window.location.href = "http://127.0.0.1:5173/";
    };
}

async function route(){
    const { code, error } = parseHashOrQuery();
    if (error){
        setHtml(`<h2>Spotify auth error</h2><pre>${error}</pre><a href="/">Back</a>`);
        return;
    }

    if (window.location.pathname === "/callback" && code){
        setHtml("<p>logging in..</p>");
        const tokenData = await exchangeCodeForToken(code);
        localStorage.setItem("spotify_access_token", tokenData.accessToken);
        window.history.replaceState({}, "", "http://127.0.0.1:5173/");
    }

    const accessToken = localStorage.getItem("spotify_access_token");
    if (!accessToken){
        setHtml(`
            <h1>Spotify Wrapped</h1>
            <p>Login to see what your top favs are.<\p>
            <button id="login">login with Spotify</button>
        `);
        document.querySelector("#login").onclick = startlogin;
        return;
    }

    setHtml("<p>Loading your Spotify Wrapped...</p>");
    await loadWrapped(accessToken);
}

route().catch(err => {
    setHtml(`<h2>Crash</h2><pre>${String(err.stack || err)}</pre>`);
});
